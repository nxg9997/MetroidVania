﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Physics : MonoBehaviour {

	//variables
	public bool IsPlayer = false;

	public Vector3 position;
	public Vector3 acceleration = Vector3.zero;
	public Vector3 velocity = Vector3.zero;

	public float maxSpeed;
	public float maxForce;

	public Vector3 speed;
    public Vector3 jump;
	public Vector3 friction;
	public Vector3 gravity;

    private bool CanGravity = true;
    private bool CanJump = false;

	// Use this for initialization
	void Start () {
		position = gameObject.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		if (IsPlayer) {
			Movement ();
            if (velocity.sqrMagnitude < .1f)
            {
                velocity = Vector3.zero;
            }
			/*if (Mathf.Abs(velocity.x) > 0 && !CanGravity) {
				ApplyForce (-friction);
			}*/
		}
        if (CanGravity) { ApplyForce(-gravity); }
		CalcSteeringForces ();
	}

	void CalcSteeringForces(){
		Vector3 ultimate = Vector3.zero;
		ultimate += acceleration;
        if (ultimate.sqrMagnitude > (maxForce * maxForce)) { Vector3.ClampMagnitude(ultimate, maxForce); }
		velocity += ultimate;
        if (velocity.sqrMagnitude > (maxSpeed * maxSpeed)) { Vector3.ClampMagnitude(velocity, maxSpeed); }
		position += velocity;
		gameObject.transform.position = position;
		acceleration = Vector3.zero;
		//velocity = Vector3.zero;
	}

	public void ApplyForce(Vector3 force){
		acceleration += force;
	}

	void Movement(){
		if (Input.GetKey (KeyCode.A) == true) {
			ApplyForce (-speed);
		}
		if (Input.GetKey (KeyCode.D) == true) {
			ApplyForce (speed);
		}

        if (!CanGravity && CanJump && Input.GetKeyDown(KeyCode.Space) == true)
        {
            ApplyForce(jump);
            CanJump = false;
            CanGravity = true;
        }
	}
    
    void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("collision detected");
        /*float dotResultV = 0f;
        dotResultV = Vector3.Dot(gameObject.transform.right, collision.transform.position);

        if (dotResultV < 0)
        {
            Debug.Log("dot is neg");
            velocity.y = 0;
            transform.position = new Vector3(transform.position.x, posY);
            CanGravity = false;
        }
        Debug.Log("dot is pos");*/

        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, .5f);
        if (hit)
        {
            //CanGravity = false;
            //transform.position = new Vector3(transform.position.x, thisY);
            CanJump = true;
            CanGravity = false;
            //transform.position = new Vector3(transform.position.x, collision.gameObject.transform.position.y + collision.gameObject.GetComponent<SpriteRenderer>().size.y / 2 + gameObject.GetComponent<SpriteRenderer>().size.y / 2);
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        CanGravity = true;
    }
}
